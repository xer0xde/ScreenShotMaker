## Privacy Policy

We value your privacy and are committed to protecting it. We do not collect any personal information from our users. We do not store or transmit your personal details, and we do not use any advertising or analytics software that talks to third parties.

### Information We Collect

We do not collect any personal information from our users.

### Contact Us

If you have any questions or concerns about our privacy policy, please contact us at privacy@istilldontcareaboutcookies.com or through a Github issue on https://github.com/OhMyGuus/I-Still-Dont-Care-About-Cookies/. We will be happy to assist you.
