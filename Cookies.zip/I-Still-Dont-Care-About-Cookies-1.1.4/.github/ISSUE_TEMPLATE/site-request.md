---
name: Site request
about: Suggest/report a website that isn't working yet.
title: "[REQ] Site request: example.com"
labels: Website request
assignees: OhMyGuus
---

**Website URL(s)**

- Example.com

**Browser**
[ ] Firefox
[x] Chrome

**Extension version**
V1.0.0
